package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.model.SharedPrefManager;
import com.example.project.model.User;

public class LecturerMenuActivity extends AppCompatActivity {

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lecturer_menu);
        context = this;

        // get user info from SharedPreferences
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        Button btnLogoutLecturer = findViewById(R.id.btnLogoutLecturer);
        btnLogoutLecturer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // clear the shared preferences
                SharedPrefManager.getInstance(getApplicationContext()).logout();

                // display message
                Toast.makeText(getApplicationContext(),
                        "You have successfully logged out.",
                        Toast.LENGTH_LONG).show();

                // forward to LoginActivity
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

            }
        });

        // assign action to Book List button
        Button btnlectconsultation = findViewById(R.id.btnlectconsultation);
        btnlectconsultation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // forward user to BookListActivity
                Intent intent = new Intent(context, ConsultationListActivity.class);
                startActivity(intent);
            }
        });
    }

}